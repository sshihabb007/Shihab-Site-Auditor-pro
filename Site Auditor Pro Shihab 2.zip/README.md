# Site Auditor Pro - Chrome Extension

This is a Chrome extension for crawling and auditing websites.

## How to Install

1.  **Download the extension files:** Make sure you have all the files in a single directory.
2.  **Open Chrome Extensions:** Open Google Chrome and navigate to `chrome://extensions`.
3.  **Enable Developer Mode:** In the top right corner, toggle the "Developer mode" switch to on.
4.  **Load Unpacked:** Click the "Load unpacked" button that appears on the top left.
5.  **Select the Directory:** In the file selection dialog, select the directory where you saved the extension files.
6.  **Done!** The "Site Auditor Pro" extension should now appear in your list of extensions and in the Chrome toolbar.

## How to Use

1.  Click the "Site Auditor Pro" icon in the Chrome toolbar to open the popup.
2.  Enter the URL of the website you want to audit.
3.  Set the crawl depth and delay between requests.
4.  Click "Start Crawl" to begin the audit.
5.  The results will be displayed in the popup. You can stop the crawl at any time by clicking "Stop Crawl".

## Icons

The icons in the `images` directory are placeholders. You can replace them with your own icons. Make sure they are in PNG format and have the following sizes:

*   `icon16.png` (16x16 pixels)
*   `icon48.png` (48x48 pixels)
*   `icon128.png` (128x128 pixels)
