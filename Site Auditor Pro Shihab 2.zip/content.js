chrome.runtime.onMessage.addListener((sshihabb007_message, sshihabb007_sender, sshihabb007_sendResponse) => {
  if (sshihabb007_message.type === 'GET_LINKS') {
    const sshihabb007_links = Array.from(document.querySelectorAll('a'))
      .map(a => a.href)
      .filter(href => href.startsWith('http'));
    sshihabb007_sendResponse({
      links: sshihabb007_links,
      depth: sshihabb007_message.payload.depth,
    });
  }
  return true; // To indicate that the response will be sent asynchronously
});
